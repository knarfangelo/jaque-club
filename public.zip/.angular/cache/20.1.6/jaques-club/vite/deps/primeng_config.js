import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-UVZH53G7.js";
import "./chunk-3D5ZY23B.js";
import "./chunk-ZH6LALFQ.js";
import "./chunk-OSBDWSLJ.js";
import "./chunk-3KKC7HMJ.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
